sudo cp ov5693.ko /lib/modules/4.9.201-tegra/kernel/drivers/media/i2c/ov5693.ko
sudo cp Image /boot/
sudo cp tegra194-p3668-dsboard-nx2-0000-tuve.dtb /boot/dtb/
echo "Update the LINUX & FDT lines in extlinux.conf"
echo "   LINUX /boot/Image"
echo "   FDT /boot/dtb/tegra194-p3668-dsboard-nx2-0000-tuve.dtb"
sudo gedit /boot/extlinux/extlinux.conf
sync
sudo reboot 

