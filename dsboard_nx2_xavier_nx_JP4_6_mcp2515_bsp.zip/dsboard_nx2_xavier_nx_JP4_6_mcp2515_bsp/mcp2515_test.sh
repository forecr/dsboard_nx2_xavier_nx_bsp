#!/bin/bash
sudo modprobe mttcan
sudo ip link set can1 up type can bitrate 500000
sudo ip link set can0 up type can bitrate 500000
gnome-terminal --title=can0 -- candump can0
gnome-terminal --title=can1 -- candump can1
while true
do
	sleep 2
	cansend can0 000#00000000
	sleep 2
	cansend can1 111#11111111 
done
