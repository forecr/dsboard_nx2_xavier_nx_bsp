#!/bin/bash

set -e

THISDIR=$(realpath `dirname $0`)

if [ $(id -u) -ne 0 ]; then
    echo "This must be run as root" >&2
    exit 1
fi

info() {
    echo ""
    echo -e "\e[34m>>>\e[0m ${@}"
}


cd ${THISDIR}
info "Building basler-camera kernel driver"
pushd basler-camera-driver >/dev/null
make -C /lib/modules/$(uname -r)/build M=$(pwd) modules
mkdir -p /lib/modules/$(uname -r)/kernel/extra
cp -av basler-camera-driver.ko /lib/modules/$(uname -r)/kernel/extra/
depmod -a
popd >/dev/null

info "Installing GenTL Producers"
dpkg -i basler-dart-bcon-mipi-gentl-producer_*_arm64.deb

info "Installing pylon"
dpkg -i pylon_*_arm64.deb

info "CEP installed sucessfully. Please reboot the system."
